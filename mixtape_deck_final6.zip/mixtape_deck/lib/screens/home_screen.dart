import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../library_store.dart';
import '../theme.dart';
import '../widgets/bottom_deck.dart';
import 'playlists_tab.dart';
import 'settings_screen.dart';
import 'tapes_tab.dart';
import 'video_tab.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _tab = 0;
  bool _searching = false;

  static const _names = ['Tapes', 'Playlists', 'Videos'];

  @override
  Widget build(BuildContext context) {
    final store = context.watch<LibraryStore>();

    return Container(
      color: kBlack,
      child: Scaffold(
        backgroundColor: Colors.transparent,
        body: SafeArea(
          bottom: false,
          child: Stack(
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Padding(
                    padding: const EdgeInsets.fromLTRB(18, 12, 4, 0),
                    child: Row(
                      children: [
                        Expanded(
                          child: Transform.scale(
                            scaleX: 1.1,
                            scaleY: 1.0,
                            alignment: Alignment.centerLeft,
                            child: const Text(
                              'TAPE EATER',
                              maxLines: 1,
                              style: TextStyle(
                                fontSize: 17,
                                fontWeight: FontWeight.w900,
                                letterSpacing: 1.2,
                              ),
                            ),
                          ),
                        ),
                        IconButton(
                          icon: Icon(_searching ? Icons.close : Icons.search),
                          onPressed: () {
                            setState(() => _searching = !_searching);
                            if (!_searching) store.setQuery('');
                          },
                        ),
                        IconButton(
                          icon: const Icon(Icons.settings),
                          onPressed: () => Navigator.of(context).push(
                              MaterialPageRoute<void>(
                                  builder: (_) => const SettingsScreen())),
                        ),
                      ],
                    ),
                  ),
                  if (_searching)
                    Padding(
                      padding: const EdgeInsets.fromLTRB(12, 4, 12, 0),
                      child: SizedBox(
                        height: 40,
                        child: TextField(
                          autofocus: true,
                          onChanged: store.setQuery,
                          style: const TextStyle(fontSize: 15),
                          decoration: InputDecoration(
                            hintText: 'Search title or artist',
                            prefixIcon: const Icon(Icons.search, size: 20),
                            filled: true,
                            fillColor: kChip,
                            contentPadding: EdgeInsets.zero,
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(12),
                              borderSide: BorderSide.none,
                            ),
                          ),
                        ),
                      ),
                    ),
                  const SizedBox(height: 24),
                  SizedBox(
                    height: 30,
                    child: ListView(
                      scrollDirection: Axis.horizontal,
                      padding: const EdgeInsets.symmetric(horizontal: 12),
                      children: [
                        for (var i = 0; i < _names.length; i++) ...[
                          GestureDetector(
                            onTap: () => setState(() => _tab = i),
                            child: Container(
                              height: 30,
                              padding: const EdgeInsets.symmetric(horizontal: 18),
                              alignment: Alignment.center,
                              decoration: BoxDecoration(
                                color: _tab == i ? kChipOrange : kChip,
                                borderRadius: BorderRadius.circular(12),
                              ),
                              child: Text(
                                _names[i],
                                style: const TextStyle(
                                  fontSize: 15,
                                  fontWeight: FontWeight.w600,
                                  color: Colors.white,
                                ),
                              ),
                            ),
                          ),
                          const SizedBox(width: 10),
                        ],
                      ],
                    ),
                  ),
                  if (store.importing) ...[
                    const SizedBox(height: 8),
                    LinearProgressIndicator(
                      value: store.progress,
                      color: kOrange,
                      backgroundColor: Colors.white12,
                      minHeight: 2,
                    ),
                    Padding(
                      padding: const EdgeInsets.fromLTRB(16, 4, 16, 0),
                      child: Text(store.status ?? 'Working…',
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(color: kMuted, fontSize: 12)),
                    ),
                  ],
                  Expanded(
                    child: IndexedStack(
                      index: _tab,
                      children: [
                        const TapesTab(),
                        const PlaylistsTab(),
                        VideoTab(onSearch: () => setState(() => _searching = true)),
                      ],
                    ),
                  ),
                ],
              ),
              const Positioned(
                left: 0,
                right: 0,
                bottom: 0,
                child: BottomDeck(),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
