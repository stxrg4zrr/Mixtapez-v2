import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:provider/provider.dart';

import '../library_store.dart';
import '../theme.dart';
import '../widgets/eat_tape.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final store = context.watch<LibraryStore>();
    return Scaffold(
      appBar: AppBar(title: const Text('Settings')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            color: kCard,
            child: ListTile(
              leading: const Icon(Icons.add_circle, color: kOrange),
              title: const Text('Eat a tape',
                  style: TextStyle(fontWeight: FontWeight.w700)),
              subtitle: const Text(
                  'Pick .zip mixtapes or .mp4 videos, hundreds at once is fine. Keep the app open while it works.'),
              onTap: store.importing ? null : () => eatTape(context),
            ),
          ),
          Card(
            color: kCard,
            child: ListTile(
              leading: const Icon(Icons.album, color: kOrange),
              title: Text('${store.count} tapes  ·  ${store.trackCount} tracks'),
              subtitle: const Text(
                  'Files are copied into the app\'s private storage. Deleting a tape removes them.'),
            ),
          ),
          FutureBuilder<PermissionStatus>(
            future: Permission.notification.status,
            builder: (context, snap) {
              final ok = snap.data?.isGranted ?? false;
              return Card(
                color: kCard,
                child: ListTile(
                  leading: Icon(
                    ok ? Icons.notifications_active : Icons.notifications_off_outlined,
                    color: ok ? kGreen : kOrange,
                  ),
                  title: const Text('Lock screen controls'),
                  subtitle: Text(ok
                      ? 'On. The player shows on the lock screen and in quick settings while music plays.'
                      : 'Off. Tap to allow notifications, otherwise Android hides the player.'),
                  trailing: const Icon(Icons.open_in_new, size: 18, color: kMuted),
                  onTap: () async {
                    final st = await Permission.notification.request();
                    if (!st.isGranted) await openAppSettings();
                  },
                ),
              );
            },
          ),
          const Card(
            color: kCard,
            child: ListTile(
              leading: Icon(Icons.cloud_off, color: kGreen),
              title: Text('Fully offline'),
              subtitle: Text(
                  'No login, no cloud, no scanning of your phone. Only what you import.'),
            ),
          ),
          const Card(
            color: kCard,
            child: ListTile(
              leading: Icon(Icons.edit_note, color: kOrange),
              title: Text('Tag edits'),
              subtitle: Text(
                  'Renames and covers are saved inside Tape Eater. Your original files are never changed.'),
            ),
          ),
        ],
      ),
    );
  }
}
