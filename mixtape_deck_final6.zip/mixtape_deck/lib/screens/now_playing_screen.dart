import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:just_audio/just_audio.dart' show LoopMode;
import 'package:provider/provider.dart';

import '../library_store.dart';
import '../player_controller.dart';
import '../theme.dart';
import '../widgets/cover_image.dart';
import '../widgets/menus.dart';
import '../widgets/seek_bar.dart';

Future<void> openNowPlaying(BuildContext context) {
  return Navigator.of(context).push(PageRouteBuilder<void>(
    transitionDuration: const Duration(milliseconds: 260),
    pageBuilder: (_, __, ___) => const NowPlayingScreen(),
    transitionsBuilder: (_, anim, __, child) => SlideTransition(
      position: Tween<Offset>(begin: const Offset(0, 1), end: Offset.zero)
          .animate(CurvedAnimation(parent: anim, curve: Curves.easeOutCubic)),
      child: child,
    ),
  ));
}

void showQueueSheet(BuildContext context) {
  showModalBottomSheet<void>(
    context: context,
    isScrollControlled: true,
    builder: (_) => const _QueueSheet(),
  );
}

class NowPlayingScreen extends StatelessWidget {
  const NowPlayingScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final pl = context.watch<PlayerController>();
    final store = context.watch<LibraryStore>();
    final r = pl.current;

    if (r == null) {
      return Scaffold(
        appBar: AppBar(),
        body: const Center(
            child: Text('Nothing playing', style: TextStyle(color: kMuted))),
      );
    }

    final fav = store.isFavorite(r.track.id);

    return Scaffold(
      backgroundColor: kBlack,
      body: GestureDetector(
        onVerticalDragEnd: (d) {
          if ((d.primaryVelocity ?? 0) > 500) Navigator.of(context).pop();
        },
        child: SafeArea(
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                child: Row(
                  children: [
                    IconButton(
                      icon: const Icon(Icons.keyboard_arrow_down_rounded, size: 34),
                      onPressed: () => Navigator.of(context).pop(),
                    ),
                    const Expanded(
                      child: Center(
                        child: Text('Now Playing',
                            style: TextStyle(fontSize: 17, color: Colors.white70)),
                      ),
                    ),
                    IconButton(
                      icon: const Icon(Icons.queue_music_rounded, size: 28),
                      onPressed: () => showQueueSheet(context),
                    ),
                  ],
                ),
              ),
              // Cover, title, seek bar and controls sit together (no big gap);
              // any spare height is split above and below the group.
              Expanded(
                child: LayoutBuilder(
                  builder: (context, c) {
                    const fixed = 22 + 60 + 66 + 92 + 16;
                    final cover = math.max(
                        160.0, math.min(c.maxWidth - 56, c.maxHeight - fixed));
                    return Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        SizedBox(
                          width: cover,
                          height: cover,
                          child: GestureDetector(
                            onTap: pl.toggle, // tap the cover = play / pause
                            child: Container(
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(26),
                                boxShadow: const [
                                  BoxShadow(
                                    color: Color(0x40FF5500),
                                    blurRadius: 60,
                                    spreadRadius: 2,
                                  ),
                                ],
                              ),
                              child: ClipRRect(
                                borderRadius: BorderRadius.circular(26),
                                child: CoverImage(
                                    path: r.album.coverPath, cacheWidth: 1000),
                              ),
                            ),
                          ),
                        ),
                        const SizedBox(height: 22),
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 28),
                          child: Column(
                            children: [
                              Text(
                                r.track.title,
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                textAlign: TextAlign.center,
                                style: const TextStyle(
                                    fontSize: 28, fontWeight: FontWeight.w800),
                              ),
                              const SizedBox(height: 4),
                              Text(
                                r.album.artist,
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: const TextStyle(fontSize: 18, color: kMuted),
                              ),
                            ],
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.fromLTRB(24, 8, 24, 0),
                          child: StreamBuilder<Duration?>(
                            stream: pl.durationStream,
                            initialData: pl.player.duration,
                            builder: (_, ds) => StreamBuilder<Duration>(
                              stream: pl.positionStream,
                              builder: (_, ps) => SeekBar(
                                position: ps.data ?? Duration.zero,
                                duration: ds.data ?? Duration.zero,
                                onSeek: pl.seek,
                              ),
                            ),
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 20),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              IconButton(
                                iconSize: 28,
                                onPressed: pl.toggleShuffle,
                                icon: Icon(Icons.shuffle_rounded,
                                    color: pl.shuffle ? kOrange : Colors.white70),
                              ),
                              IconButton(
                                iconSize: 42,
                                onPressed: pl.previous,
                                icon: const Icon(Icons.skip_previous_rounded),
                              ),
                              IconButton(
                                iconSize: 76,
                                onPressed: pl.toggle,
                                icon: Icon(pl.playing
                                    ? Icons.pause_rounded
                                    : Icons.play_arrow_rounded),
                              ),
                              IconButton(
                                iconSize: 42,
                                onPressed: pl.next,
                                icon: const Icon(Icons.skip_next_rounded),
                              ),
                              IconButton(
                                iconSize: 28,
                                onPressed: () => store.toggleFavorite(r.track.id),
                                icon: Icon(
                                  fav ? Icons.favorite : Icons.favorite_border,
                                  color: fav ? kOrange : Colors.white70,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    );
                  },
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(20, 0, 20, 8),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    IconButton(
                      iconSize: 26,
                      onPressed: pl.cycleLoop,
                      icon: Icon(
                        pl.loop == LoopMode.one
                            ? Icons.repeat_one_rounded
                            : Icons.repeat_rounded,
                        color: pl.loop == LoopMode.off ? Colors.white70 : kOrange,
                      ),
                    ),
                    TextButton(
                      onPressed: () {
                        final nav = Navigator.of(context);
                        nav.pop();
                        pl.stop();
                      },
                      child: const Text('stop',
                          style: TextStyle(color: kOrange, fontSize: 18)),
                    ),
                    IconButton(
                      iconSize: 26,
                      onPressed: () => showAddToPlaylist(context, [r.track.id]),
                      icon: const Icon(Icons.playlist_add_rounded,
                          color: Colors.white70),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _QueueSheet extends StatelessWidget {
  const _QueueSheet();

  @override
  Widget build(BuildContext context) {
    final pl = context.watch<PlayerController>();
    final h = MediaQuery.of(context).size.height * 0.7;
    return SizedBox(
      height: h,
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 16, 20, 8),
            child: Row(
              children: [
                Text('Queue  ·  ${pl.queue.length}',
                    style: const TextStyle(
                        fontSize: 18, fontWeight: FontWeight.w800)),
              ],
            ),
          ),
          Expanded(
            child: ReorderableListView.builder(
              buildDefaultDragHandles: false,
              itemCount: pl.queue.length,
              onReorder: (o, n) {
                if (n > o) n -= 1;
                pl.move(o, n);
              },
              itemBuilder: (c, i) {
                final it = pl.queue[i];
                final cur = i == pl.index;
                return ListTile(
                  key: ValueKey('q${i}_${it.track.id}'),
                  leading: ClipRRect(
                    borderRadius: BorderRadius.circular(8),
                    child: SizedBox(
                      width: 44,
                      height: 44,
                      child: CoverImage(path: it.album.coverPath, cacheWidth: 120),
                    ),
                  ),
                  title: Text(it.track.title,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                          fontWeight: FontWeight.w600,
                          color: cur ? kOrange : Colors.white)),
                  subtitle: Text(it.album.artist,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(color: kMuted)),
                  onTap: () => pl.jumpTo(i),
                  trailing: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      IconButton(
                        icon: const Icon(Icons.close, size: 20, color: kMuted),
                        onPressed: () => pl.removeAt(i),
                      ),
                      ReorderableDragStartListener(
                        index: i,
                        child: const Padding(
                          padding: EdgeInsets.all(8),
                          child: Icon(Icons.drag_handle, color: kMuted),
                        ),
                      ),
                    ],
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
