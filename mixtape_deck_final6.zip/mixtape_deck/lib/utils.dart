import 'dart:io';

import 'package:flutter/services.dart' show rootBundle;
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';

/// File path of the default cover (copied out of the assets at startup so the
/// lock-screen / notification player can show it too).
String defaultCoverPath = '';

Future<void> prepareDefaultCover() async {
  final dir = await getApplicationSupportDirectory();
  final f = File(p.join(dir.path, 'default_cover.jpg'));
  if (!await f.exists()) {
    final data = await rootBundle.load('assets/default_cover.jpg');
    await f.writeAsBytes(data.buffer.asUint8List());
  }
  defaultCoverPath = f.path;
}

String fmtDuration(Duration d) {
  final m = d.inMinutes;
  final s = d.inSeconds.remainder(60);
  return '$m:${s.toString().padLeft(2, '0')}';
}

int clampInt(int v, int lo, int hi) => v < lo ? lo : (v > hi ? hi : v);

/// A-Z letter for the alphabet scroller, or '#' for everything else.
String letterOf(String s) {
  final t = s.trimLeft();
  if (t.isEmpty) return '#';
  final c = t[0].toUpperCase();
  final u = c.codeUnitAt(0);
  return (u >= 65 && u <= 90) ? c : '#';
}
