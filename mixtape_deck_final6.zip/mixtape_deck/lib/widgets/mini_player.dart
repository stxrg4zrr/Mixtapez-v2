import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../player_controller.dart';
import '../screens/now_playing_screen.dart';
import '../theme.dart';
import 'cover_image.dart';

/// Docked player bar at the bottom of album / playlist pages.
/// Tap = Now Playing, swipe left = next, swipe right = previous.
class MiniPlayer extends StatelessWidget {
  const MiniPlayer({super.key});

  @override
  Widget build(BuildContext context) {
    final pl = context.watch<PlayerController>();
    final r = pl.current;
    if (r == null) return const SizedBox.shrink();

    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: () => openNowPlaying(context),
      onHorizontalDragEnd: (d) {
        final v = d.primaryVelocity ?? 0;
        if (v < -300) {
          pl.next();
        } else if (v > 300) {
          pl.previous();
        }
      },
      child: Material(
        color: kCard,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            StreamBuilder<Duration>(
              stream: pl.positionStream,
              builder: (context, snap) {
                final total = pl.player.duration?.inMilliseconds ?? 0;
                final pos = snap.data?.inMilliseconds ?? 0;
                final v = total > 0 ? (pos / total).clamp(0.0, 1.0).toDouble() : 0.0;
                return LinearProgressIndicator(
                  value: v,
                  minHeight: 2,
                  color: kOrange,
                  backgroundColor: Colors.white12,
                );
              },
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(12, 8, 4, 8),
              child: Row(
                children: [
                  ClipRRect(
                    borderRadius: BorderRadius.circular(6),
                    child: SizedBox(
                      width: 44,
                      height: 44,
                      child: CoverImage(path: r.album.coverPath, cacheWidth: 120),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(r.track.title,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(fontWeight: FontWeight.w700)),
                        Text(r.album.artist,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(color: Colors.white54, fontSize: 12)),
                      ],
                    ),
                  ),
                  IconButton(
                    icon: const Icon(Icons.skip_previous_rounded),
                    onPressed: pl.previous,
                  ),
                  IconButton(
                    icon: Icon(
                      pl.playing ? Icons.pause_circle_filled : Icons.play_circle_fill,
                      size: 36,
                      color: kOrange,
                    ),
                    onPressed: pl.toggle,
                  ),
                  IconButton(
                    icon: const Icon(Icons.skip_next_rounded),
                    onPressed: pl.next,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
