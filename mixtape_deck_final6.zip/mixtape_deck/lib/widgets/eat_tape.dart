import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../library_store.dart';

/// Opens the system picker for .zip mixtapes and .mp4 videos and imports them.
/// Handles big batches: files are processed one by one, each cached copy is
/// deleted right after it is extracted, and one bad zip never stops the rest.
Future<void> eatTape(BuildContext context) async {
  final store = context.read<LibraryStore>();
  final messenger = ScaffoldMessenger.of(context);
  if (store.importing) return;

  final res = await FilePicker.platform.pickFiles(
    type: FileType.custom,
    allowedExtensions: const ['zip', 'mp4', 'mov', 'm4v'],
    allowMultiple: true,
  );
  if (res == null) return;

  final zips = res.files
      .where((f) => f.path != null)
      .map((f) => MapEntry(f.path!, f.name))
      .toList();
  if (zips.isEmpty) return;

  final result = await store.importZips(zips);
  try {
    await FilePicker.platform.clearTemporaryFiles();
  } catch (_) {}

  messenger.hideCurrentSnackBar();
  if (result.failures.isEmpty) {
    messenger.showSnackBar(SnackBar(
      content: Text(result.ok == 1 ? 'Tape added' : '${result.ok} tapes added'),
    ));
  } else if (context.mounted) {
    await showDialog<void>(
      context: context,
      builder: (d) => AlertDialog(
        title: Text('${result.ok} added, ${result.failures.length} failed'),
        content: SingleChildScrollView(
          child: Text(result.failures.join('\n\n')),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(d), child: const Text('OK')),
        ],
      ),
    );
  }
}
