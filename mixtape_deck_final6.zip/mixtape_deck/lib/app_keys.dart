import 'package:flutter/material.dart';

/// Lets non-UI code (the player) show a snackbar.
final GlobalKey<ScaffoldMessengerState> messengerKey =
    GlobalKey<ScaffoldMessengerState>();
